package ui;

import java.util.Scanner;

import model.Club;
import model.Employee;
import model.EmployeeType;
import model.Expertise;
import model.Formation;
import model.MainCoach;
import model.Player;
import model.Position;
import model.State;
import model.Tactic;
import model.TechnicalAssistant;


public class Main {
	private Club controller;
	Scanner reader;

	public static void main(String[] args) {
		Main m = new Main();
	}

	
	/**
	 * 
	 */
	public Main() {

		reader = new Scanner(System.in);
		int nit;
		String name, establishedDate;
		System.out.println("Welcome to your new soccer club");
		System.out.println("Please input your soccer club's name");
		name=reader.nextLine();
		System.out.println("Please imput the nit");
		nit=reader.nextInt();
		reader.nextLine();
		System.out.println("Please input the date your club was established");
		establishedDate=reader.nextLine();

		controller = new Club(name, nit, establishedDate);
		boolean exit = false;

		do {
			showMenu();
			int option = reader.nextInt();
			reader.nextLine();

			switch (option) {
			case 1:
				hireEmployee();
				break;
			case 2:
				fireEmployee();
				break;
			case 3:
				addEmployeeToTeam();
				break;
			case 4:
				addFormationToTeam();
				break;
			case 5:
				assignCoachToOffice();
				break;
			case 6:
				addPlayerToLockerRoom();
				break;
			case 7:
				showInfo();
				break;
			case 8:
				updateTeamOrEmployee();
				break;
			case 9:

				System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
				System.out.println("~~~~~~~~~~~~~ GOODBYE ~~~~~~~~~~~~~");
				System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
				exit = true;

				break;

			default:
				System.out.println("INCORRECT OPTION. PLEASE SELECT A VALID OPTION");
				break;
			}
		} while (!exit);

	}
	/**
	 * 
	 */
	public void showMenu() {
		System.out.println("++++++++++++++++++++++++++++++++++++++++++++++");
		System.out.println("+++++ Welcome. Please select an option. ++++++");
		System.out.println("1. Hire employee.");
		System.out.println("2. Fire employee.");
		System.out.println("3. Add employee to team.");
		System.out.println("4. Add formation to a team.");
		System.out.println("5. Assign office to coach");
		System.out.println("6. Add player to locker room");
		System.out.println("7. See club info");
		System.out.println("8. Update team or employee");
		System.out.println("9. Exit.");
		System.out.println("++++++++++++++++++++++++++++++++++++++++++++++");
	}

	/**
	 * 
	 */
	public void hireEmployee() {
		System.out.println("++++++++++++++++++++++++++++++++++++++++++++++");
		System.out.println("+++++  Please select the type of employee you want to create. ++++++");
		System.out.println("1. Player.");
		System.out.println("2. Main Coach.");
		System.out.println("3. Technical assistant.");
		System.out.println("++++++++++++++++++++++++++++++++++++++++++++++");
		boolean fail=false;
		int option = reader.nextInt();
		reader.nextLine();
		Employee newEmployee = null;
		System.out.println("Please input the employee's name.");
		String name = reader.nextLine();
		System.out.println("Please input the employee's id.");
		int id = reader.nextInt();
		reader.nextLine();
		System.out.println("Please input the employee's salary.");
		double salary = reader.nextDouble();
		reader.nextLine();
		System.out.println("Please input the employee's state (1 active, 2 or any other number inactive).");
		int st = reader.nextInt();
		reader.nextLine();
		State state;
		if (st==1) {
			state=State.ACTIVE;
		}
		else
		{
			state=State.INACTIVE;
		}
		switch (option) {
		case 1:
			System.out.println("The employee to be hired will be a Player.");
			System.out.println("Please input the player's jerseyNumber.");
			int jerseyNumber = reader.nextInt();
			System.out.println("Please input the player's carreer goals.");
			int goals = reader.nextInt();
			System.out.println("Please input the player's average score.");
			double averageScore = reader.nextDouble();
			Position position = selectPlayerPosition();
			newEmployee = new Player(name, id, salary, state, jerseyNumber, goals, averageScore, position, EmployeeType.PLAYER);
			break ;
		case 2:
			System.out.println("The employee to be hired will be a Main Coach.");
			System.out.println("Please input the Main Coach's number of championships won.");
			int numberChampionships = reader.nextInt();
			System.out.println("Please input the Main Coach's carreer experience in years.");
			int experience = reader.nextInt();
			newEmployee = new MainCoach(name, id, salary, state, experience, numberChampionships, EmployeeType.MAIN_COACH);
			break ;
		case 3:
			System.out.println("The employee to be hired will be a Technical Assistante.");
			Expertise expertise = selectTAExpertise();
			System.out.println("Was the technical assistant a pro player? (1 yes, any other number no).");
			int wasPro = reader.nextInt();
			boolean proPlayer=false;
			if (wasPro==1) {
				proPlayer=true;
			}
			System.out.println("Please input the Main Coach's carreer experience in years.");
			experience = reader.nextInt();
			newEmployee = new TechnicalAssistant(name, id, salary, state, experience, proPlayer, expertise, EmployeeType.TECHNICAL_ASSISTANT);
			break ;

		default:
			System.out.println("Invalid number, try again.");
			fail=true;
		}
		if(!fail)
			if(controller.addEmployee(newEmployee, option))
			{
				System.out.println("Employee hired successfully.");
			}
			else
			{
				System.out.println("The id was already taken please try again.");
			}


	}

	/**
	 * 
	 */
	public void fireEmployee()
	{
		System.out.println("+++++  Please enter the id of the employee you are going to fire. ++++++");
		int id = reader.nextInt();
		reader.nextLine();
		if(controller.removeEmployee(id))
			System.out.println("Employee was fired successfully.");
		else
			System.out.println("There is no employee with that id");

	}

	/**
	 * 
	 */
	public void addEmployeeToTeam()
	{
		System.out.println("+++++  Please enter the name of the team. ++++++");
		String teamName = reader.nextLine();
		System.out.println("+++++  Please enter the id of the employee to be added. ++++++");
		int id = reader.nextInt();
		if(controller.addEmployeeToTeam(id, teamName))
			System.out.println("Employee was added to team " +teamName+ " successfully.");
		else
			System.out.println("The employee could not be added.");

	}

	/**
	 * 
	 */
	public void assignCoachToOffice()
	{
		System.out.println("+++++  Please enter the id of the coach to be assigned to an office. ++++++");
		int id = reader.nextInt();
		if(controller.addCoachToOffice(id))
			System.out.println("Employee was assigned to an office successfully.");
		else
			System.out.println("The coach could not be assigned an office.");

	}

	/**
	 * 
	 */
	public void addPlayerToLockerRoom()
	{
		System.out.println("+++++  Please enter the id of the player to be assigned. ++++++");
		int id = reader.nextInt();
		if(controller.addPlayerToLockerRoom(id))
			System.out.println("Player was added to the locker room successfully.");
		else
			System.out.println("The player could not be added.");

	}

	/**
	 * 
	 */
	public void addFormationToTeam()
	{
		System.out.println("+++++  Please enter the name of the team. ++++++");
		String teamName = reader.nextLine();
		System.out.println("+++++  Please enter the date for the formation. ++++++");
		String date= reader.nextLine();
		Tactic tactic = selectFormationTactic();
		int matrix[][] = new int [10][7];
		System.out.println("+++++  Please enter the matrix for the formation only 1s and 0s. ++++++");

		for (int i = 0; i < 10; i++) {
			for (int j = 0; j < 7; j++) {
				System.out.println("+++++  Please enter the value for the position ("+ (i+1)+" , "+(j+1)+") . ++++++");
				int num;
				do {
					num=reader.nextInt();
				} while (num>1 || num<0);
				matrix[i][j] = num;
			}
		}

		System.out.println("+++++  This is your formation matrix ++++++");

		for (int i = 0; i < 10; i++) {
			for (int j = 0; j < 7; j++) {
				System.out.print(matrix[i][j]+" ");
			}
			System.out.println();
		}

		Formation formation = new Formation(matrix, date, tactic);
		if(controller.addFormationToTeam(formation, teamName))

			System.out.println("The formation was added to team " +teamName+ " successfully.");
		else
			System.out.println("The team name is invalid.");
	}

	/**
	 * @return
	 */
	public Position selectPlayerPosition()
	{
		System.out.println("++++++++++++++++++++++++++++++++++++++++++++++");
		System.out.println("+++++  Please select the type of player you want to create. ++++++");
		System.out.println("1. Goalkeeper.");
		System.out.println("2. Defense.");
		System.out.println("3. Midfielder.");
		System.out.println("4. Striker.");
		System.out.println("++++++++++++++++++++++++++++++++++++++++++++++");
		int number = reader.nextInt();
		Position p = null;
		do {
			switch (number) {
			case 1:
				p = Position.GOALKEEPER;
				break;
			case 2:
				p = Position.DEFENSE;
				break;
			case 3:
				p = Position.MIDFIELDER;
				break;
			case 4:
				p = Position.STRIKER;
				break;
			default:
				System.out.println("Invalid number, try again.");
			}
		} while (p==null); 
		return p;
	}

	/**
	 * @return
	 */
	public Tactic selectFormationTactic()
	{
		System.out.println("++++++++++++++++++++++++++++++++++++++++++++++");
		System.out.println("+++++  Please select the type tactic for the formation. ++++++");
		System.out.println("1. Counter.");
		System.out.println("2. Defect.");
		System.out.println("3. High Pressure.");
		System.out.println("4. Posession.");
		System.out.println("++++++++++++++++++++++++++++++++++++++++++++++");
		int number = reader.nextInt();
		Tactic t = null;
		do {
			switch (number) {
			case 1:
				t = Tactic.COUNTER;
				break;
			case 2:
				t = Tactic.DEFECT;
				break;
			case 3:
				t = Tactic.HIGH_PRESSURE;
				break;
			case 4:
				t = Tactic.POSESSION;
				break;
			default:
				System.out.println("Invalid number, try again.");
			}
		} while (t==null); 
		return t;
	}

	/**
	 * @return
	 */
	public Expertise selectTAExpertise()
	{
		System.out.println("++++++++++++++++++++++++++++++++++++++++++++++");
		System.out.println("+++++  Please select the Technical Assistants expertise. ++++++");
		System.out.println("1. Defense.");
		System.out.println("2. Offense.");
		System.out.println("3. Posession.");
		System.out.println("4. Lab Plays.");
		System.out.println("++++++++++++++++++++++++++++++++++++++++++++++");
		int number = reader.nextInt();
		Expertise e = null;
		do {
			switch (number) {
			case 1:
				e = Expertise.DEFESE;
				break;
			case 2:
				e = Expertise.OFFENSE;
				break;
			case 3:
				e = Expertise.POSESSION;
				break;
			case 4:
				e = Expertise.LAB_PLAYS;
				break;
			default:
				System.out.println("Invalid number, try again.");
			}
		} while (e==null); 
		return e;
	}

	/**
	 * 
	 */
	public void showInfo()
	{
		System.out.println("++++++++++++++++++++++++++++++++++++++++++++++");
		System.out.println("+++++  Please select the aspect of the club for which you wish to see information. ++++++");
		System.out.println("1. Club.");
		System.out.println("2. Teams.");
		System.out.println("3. Specific team.");
		System.out.println("4. Employees.");
		System.out.println("5. Specific employee.");
		System.out.println("6. Offices.");
		System.out.println("7. Locker rooms.");
		System.out.println("++++++++++++++++++++++++++++++++++++++++++++++");
		int number = reader.nextInt();
		reader.nextLine();
		Expertise e = null;
		do {
			switch (number) {
			case 1:
				System.out.println(controller.toString());
				break;
			case 2:
				System.out.println(controller.getInfoAllTeams());
				break;
			case 3:
				System.out.println("+++++  Please enter the name of the team. ++++++");
				String teamName = reader.nextLine();
				System.out.println(controller.getInfoTeam(teamName));
				break;
			case 4:
				System.out.println(controller.getInfoAllEmployees());
				break;
			case 5:
				System.out.println("Please input the employee's id.");
				int id = reader.nextInt();
				reader.nextLine();
				System.out.println(controller.getInfoEmployeeId(id));
				break;
			case 6:
				System.out.println(controller.stateOfOffices());
				break;
			default:
				System.out.println("Invalid number, try again.");
			}
		} while (e==null); 

	}

	/**
	 * 
	 */
	public void updateTeamOrEmployee()
	{
		System.out.println("++++++++++++++++++++++++++++++++++++++++++++++");
		System.out.println("+++++  Please select the option you want to update. ++++++");
		System.out.println("1. Employee.");
		System.out.println("2. Team.");
		System.out.println("++++++++++++++++++++++++++++++++++++++++++++++");
		int number = reader.nextInt();
		reader.nextLine();

		switch (number) {
		case 1:
			System.out.println("+++++  Please enter the id of the employee. ++++++");
			int id = reader.nextInt();
			reader.nextLine();
			System.out.println("+++++  Please enter new the name of the employee. ++++++");
			String newName = reader.nextLine();
			System.out.println("+++++  Please enter the id of the employee. ++++++");
			double newSalary = reader.nextDouble();
			reader.nextLine();
			System.out.println("Please input the employee's new state (1 active, 2 or any other number inactive).");
			int st = reader.nextInt();
			reader.nextLine();
			State newState;
			if (st==1) {
				newState=State.ACTIVE;
			}
			else
			{
				newState=State.INACTIVE;
			}
			controller.updateEmployee(id, newName, newSalary, newState);
			break;
		case 2:
			System.out.println("+++++  Please enter the name of the team. ++++++");
			String teamName = reader.nextLine();
			System.out.println("+++++  Please enter new the name of the team. ++++++");
			newName = reader.nextLine();
			controller.updateTeam(teamName, newName);
			break;
		default:
			System.out.println("Invalid number, try again.");
		}


	}


}

