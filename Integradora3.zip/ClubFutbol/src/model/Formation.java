package model;

public class Formation {
	private int[][] matrix;
	private String date;
	private Tactic tactic;
	/**
	 * Description This is the constructor method of the Formation class
	 * @param matrix the matrix that represents the formation in 1 and 0s
	 */
	public Formation(int[][] matrix,String date, Tactic tactic) {
		this.matrix = matrix;
		this.date=date;
		this.tactic=tactic;
	}
	/**
	 * Description This method returns the matrix that represents the formation in 1 and 0s
	 * @return the matrix that represents the formation in 1 and 0s
	 */
	public int[][] getMatrix() {
		return matrix;
	}

	/**
	 * Description This method sets the matrix that represents the formation in 1 and 0s
	 * @param the matrix that represents the formation
	 */
	public void setMatrix(int[][] matrix) {
		this.matrix = matrix;
	}

	/**
	 * Description This method returns a string describing the formation (eg. 4-4-2)
	 * @return the string value equivalent to the formation
	 */
	public String toString()
	{
		String ans="";
		for(int i =matrix.length-1;i>=0; i--)
		{ int cont=0;
		for (int j=0;j<matrix[0].length;j++ )
		{
			if(matrix[i][j]==1)
			{
				cont++;
			}

		}
		if(ans.isBlank())
		{
			if(cont>0)
				ans+=cont;
		}
		else
		{
			if(cont>0)
				ans+="-"+cont;
		}
		}
		return ans;
	}
	/**
	 * Description this method gets the formation's date
	 * @return the formation's date
	 */
	public String getDate() {
		return date;
	}
	/**
	 * Description this method sets the formation's date
	 * @param date the formation's date
	 */
	public void setDate(String date) {
		this.date = date;
	}
	/**
	 * Description this method gets the formation's tactic
	 * @return the formation's tactic
	 */
	public Tactic getTactic() {
		return tactic;
	}
	/**
	 * Description this method sets the formation's tactic
	 * @param tactic the formation's tactic
	 */
	public void setTactic(Tactic tactic) {
		this.tactic = tactic;
	}


}
