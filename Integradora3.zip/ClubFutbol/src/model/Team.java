package model;

import java.util.ArrayList;

public class Team {
	public static final int PLAYERS=25;
	public static final int TAS=3;
	private String name;
	private Player[] mainRoster;
	private MainCoach mainCoach;
	private TechnicalAssistant[] technicalAssistants;
	private ArrayList<Formation> formations;
	private LockerRoom lockerRoom;
	/**
	 * Description this is the constructor of the Team class
	 * @param name Team's name
	 */
	public Team(String name ) {
		this.name = name;
		this.mainRoster = new Player[PLAYERS];
		this.technicalAssistants = new TechnicalAssistant[TAS];
		this.mainCoach=null;
		this.formations = new ArrayList<Formation>();
		lockerRoom=null;
	}
	/**
	 * Description this method gets the team's name
	 * @return the team's name
	 */
	public String getName() {
		return name;
	}
	/**
	 * Description this method sets the team's name
	 * @param name the team's name
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * Description this method gets the team's main roster
	 * @return the team's main roster
	 */
	public Player[] getMainRoster() {
		return mainRoster;
	}
	/**
	 * Description this method sets the team's main roster
	 * @param mainRoster the team's main roster
	 */
	public void setMainRoster(Player[] mainRoster) {
		this.mainRoster = mainRoster;
	}
	/**
	 * Description this method gets the team's main coach
	 * @return the team's main coach
	 */
	public MainCoach getMainCoach() {
		return mainCoach;
	}
	/**
	 * Description this method sets the team's main coach
	 * @param mainCoach the team's main coach
	 */
	public void setMainCoach(MainCoach mainCoach) {
		int inCharge = mainCoach.getNumberTeamsInCharge()+1;
		mainCoach.setNumberTeamsInCharge(inCharge);
		this.mainCoach = mainCoach;
	}
	/**
	 * Description this method gets the team's technical assistants
	 * @return the team's technical assistants
	 */
	public TechnicalAssistant[] getTechnicalAssistants() {
		return technicalAssistants;
	}
	/**
	 * Description this method sets the team's technical assistants
	 * @param technicalAssistants the team's technical assistants
	 */
	public void setTechnicalAssistants(TechnicalAssistant[] technicalAssistants) {
		this.technicalAssistants = technicalAssistants;
	}
	/**
	 * Description this method gets the team's formations
	 * @return the team's formations
	 */
	public ArrayList<Formation> getFormations() {
		return formations;
	}
	/**
	 * Description this method sets the team's formations
	 * @param formations the team's formations
	 */
	public void setFormations(ArrayList<Formation> formations) {
		this.formations = formations;
	}
	/**
	 * Description this method gets the team's locker rooms
	 * @return the team's locker rooms
	 */
	public LockerRoom getLockerRoom() {
		return lockerRoom;
	}
	/**
	 * Description this method sets the team's locker rooms
	 * @param lockerRoom the team's locker rooms
	 */
	public void setLockerRoom(LockerRoom lockerRoom) {
		this.lockerRoom = lockerRoom;
	}
	/**
	 * Description this method adds a player to the team
	 * @param player
	 * @return true if the player could be added, false if there was no space on the roster.
	 */
	public boolean addPlayer(Player player)
	{
		for (int i = 0; i < mainRoster.length; i++) {
			if (mainRoster[i]==null) {
				player.setTeam(this);
				mainRoster[i]=player;
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Description this method adds a technical assistant to the team
	 * @param ta techincal assistant
	 * @return true if the techincal assistant could be added, false if there was no space on the roster.
	 */
	public boolean addTA(TechnicalAssistant ta)
	{
		for (int i = 0; i < technicalAssistants.length; i++) {
			if (technicalAssistants[i]==null) {
				technicalAssistants[i]=ta;
				return true;
			}
		}
		return false;
	}

	/**
	 * Description this method removes a player from the team
	 * @param id the players id
	 */
	public void removePlayer(int id)
	{
		for (int i = 0; i < mainRoster.length; i++) {
			if (mainRoster[i]!=null) {
				if(mainRoster[i].getId()==id)
					mainRoster[i]=null;
			}
		}
	}
	
	/**
	 * Description this method adds a formation to the team
	 * @param f formation
	 */
	public void addFormation(Formation f)
	{
		formations.add(f);
	}
	
	/**
	 * Description this method generates a string with the team's info
	 *@return string with the team's info
	 */
	@Override
	public String toString() {
		String s=name+"\n";
		if (mainCoach!=null) {
			s+="Main coach: "+mainCoach.getName();
		}
		else
		{
			s+="No main coach has been assigned\n";
		}
		s+="Technical assistants\n";
		for (TechnicalAssistant technicalAssistant : technicalAssistants) {
			if (technicalAssistant!=null) {
				s+=technicalAssistant.getName()+"\n";
			}
		}
		s+="Main roster\n";
		for (Player player : mainRoster) {
			if (player!=null) {
				s+=player.getName()+"\n";
			}
		}
		s+="Number of formations "+formations.size();
		return s;
	}
}
