package model;

public class Coach extends Employee{
	protected int experienceYears;
	/**
	 * Description this is the constructor of the Coach class
	 * @param name coach's name
	 * @param id coach's id
	 * @param salary coach's salary
	 * @param state coach's state
	 * @param experience coach's experience
	 * @param type coach's type
	 */
	public Coach(String name, int id, double salary, State state, int experience, EmployeeType type) {
		super(name, id, salary, state, type);
		this.experienceYears=experience;

	}
	/**
	 * Description  this method gets the coach's experience years 
	 * @return the coach's experience years
	 */
	public int getExperienceYears() {
		return experienceYears;
	}
	/**
	 * Description this method sets the coach's experience years
	 * @param experienceYears the coach's experience years
	 */
	public void setExperienceYears(int experienceYears) {
		this.experienceYears = experienceYears;
	}

	/**
	 * Description this method generates a string with the coach's information
	 */
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		String s=  super.toString();
		s+=experienceYears+"years of experience\n";
		return s;
	}
}
