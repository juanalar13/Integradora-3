package model;

public enum Tactic {
POSESSION, COUNTER, HIGH_PRESSURE, DEFECT;
}
