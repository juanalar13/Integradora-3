package model;

public enum EmployeeType {
	MAIN_COACH, PLAYER, EMPLOYEE, TECHNICAL_ASSISTANT, COACH;
}
