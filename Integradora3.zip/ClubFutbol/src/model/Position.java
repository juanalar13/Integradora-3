package model;

public enum Position
{
	GOALKEEPER, DEFENSE, MIDFIELDER, STRIKER
}