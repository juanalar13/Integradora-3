package model;

public class Employee {
	private String name;
	private int id;
	protected double salary;
	private State state;
	protected EmployeeType type;
	/**
	 * Description This method is the constructor for the employee class
	 * @param name employee's name
	 * @param id employee's id
	 * @param salary employee's salary
	 * @param state employee's state
	 * @param type employee's type
	 */
	public Employee(String name, int id, double salary, State state, EmployeeType type) {
		
		this.name = name;
		this.id = id;
		this.salary = salary;
		this.state = state;
		this.type=type;
	}
	/**
	 * Description This method gets the employee's name
	 * @return  the employee's name
	 */
	public String getName() {
		return name;
	}
	/**
	 * Description This method sets the employee's name
	 * @param name the employee's name
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * Description This method gets the employee's id
	 * @return the employee's id
	 */
	public int getId() {
		return id;
	}
	/**
	 * Description This method sets the employee's id
	 * @param id the employee's id
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * Description This method gets the employee's salary
	 * @return the employee's salary
	 */
	public double getSalary() {
		return salary;
	}
	/**
	 * Description This method sets the employee's salary
	 * @param salary the employee's salary
	 */
	public void setSalary(double salary) {
		this.salary = salary;
	}
	/**
	 * Description This method gets the employee's state
	 * @return the employee's state
	 */
	public State getState() {
		return state;
	}
	/**
	 * Description This method sets the employee's state
	 * @param state the employee's state
	 */
	public void setState(State state) {
		this.state = state;
	}
	/**
	 * Description This method gets the employee's type
	 * @return the employee's type
	 */
	public EmployeeType getType() {
		return type;
	}
	/**
	 * Description This method sets the employee's type
	 * @param type the employee's type
	 */
	public void setType(EmployeeType type) {
		this.type = type;
	}
	/**
	 * Description This method generates a string with the employee's info
	 * @return String with the employee's info
	 */
	public String toString()
	{
		String s= id+"\n"+name+"\n"+salary+"\n"+state+"\n"+type;
		return s;
	}

}
