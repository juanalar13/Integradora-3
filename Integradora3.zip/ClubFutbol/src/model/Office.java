package model;

public class Office {
	
	private Coach coach;
	private int id;
	/**
	 * Description This is the constructor of the Office class
	 * @param id the office's id
	 */
	public Office(int id) {
		coach=null;
		this.id= id;
	}
	/**
	 * Description This method gets the coach that is in the office
	 * @return the coach
	 */
	public Coach getCoach() {
		return coach;
	}
	/**
	 * Description This method sets the coach
	 * @param the coach that is assigned to the office
	 */
	public void setCoach(Coach coach) {
		this.coach = coach;
	}
	/**
	 * Description This method tells whether the office is empty or not
	 * @return if the office is empty or not
	 */
	public boolean isEmpty()
	{
		if(coach==null)
			return true;
		return false;
	}
	/**
	 * Description This method gets the office's id
	 * @return the office's id
	 */
	public int getId() {
		return id;
	}
	/**
	 * Description This method sets the office's id
	 * @param id the office's id
	 */
	public void setId(int id) {
		this.id = id;
	}
	
	/**
	 * Description this method generates a string with the office's info
	 *@return string with the office's info
	 */
	@Override
	public String toString() {
		String s="[x]";
		if (isEmpty()) {
			s="[ ]";
		}
		return s;
	}
	
}
