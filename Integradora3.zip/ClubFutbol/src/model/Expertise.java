package model;

public enum Expertise {
DEFESE,OFFENSE, POSESSION, LAB_PLAYS;
}
