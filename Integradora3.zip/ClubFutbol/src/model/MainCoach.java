package model;

public class MainCoach extends Coach{
	private int numberTeamsInCharge;
	private int numberChampionships;
	private double marketPrice;
	private double level;
	/**
	 * Description this is the constructor of the MainCoach class
	 * @param name coach's name
	 * @param id coach's id
	 * @param salary coach's salary
	 * @param state coach's state
	 * @param experience coach's experience
	 * @param type coach's type
	 * @param numberChampionships coach's number of championships won
	 */
	public MainCoach(String name, int id, double salary, State state, int experience,
			int numberChampionships, EmployeeType type) {
		super(name, id, salary, state, experience, type);
		this.numberTeamsInCharge = 0;
		this.numberChampionships = numberChampionships;
		calcMarketPrice();
		calcLevel();
	}
	/**
	 * Description this method gets the main coach's number of teams in charge
	 * @return the main coach's number of teams in charge
	 */
	public int getNumberTeamsInCharge() {
		return numberTeamsInCharge;
	}
	/**
	 * Description this method sets the main coach's number of teams in charge
	 * @param numberTeamsInCharge the main coach's number of teams in charge
	 */
	public void setNumberTeamsInCharge(int numberTeamsInCharge) {
		this.numberTeamsInCharge = numberTeamsInCharge;
	}
	/**
	 * Description this method gets the main coach's number of won championships 
	 * @return the main coach's number of won championships 
	 */
	public int getNumberChampionships() {
		return numberChampionships;
	}
	/**
	 * Description this method sets the main coach's number of won championships 
	 * @param numberChampionships the main coach's number of won championships 
	 */
	public void setNumberChampionships(int numberChampionships) {
		this.numberChampionships = numberChampionships;
	}
	/**
	 * Description this method gets the main coach's market price
	 * @return the main coach's market price
	 */
	public double getMarketPrice() {
		calcMarketPrice();
		return marketPrice;
	}
	/**
	 * Description this method sets the main coach's market price
	 * @param marketPrice
	 */
	public void setMarketPrice(double marketPrice) {
		this.marketPrice = marketPrice;
	}
	/**
	 * Description this method gets the main coach's level
	 * @return the main coach's level
	 */
	public double getLevel() {
		calcLevel();
		return level;
	}
	/**
	 * Description this method sets the main coach's level
	 * @param level the main coach's level
	 */
	public void setLevel(double level) {
		this.level = level;
	}

	/**
	 * Description this method calculates the main coach's market price
	 */
	public void calcMarketPrice()
	{
		marketPrice = (salary*10)+(experienceYears*100)+(numberChampionships*50);
	}

	/**
	 * Description this method calculates the main coach's level
	 */
	public void calcLevel()
	{
		level = 5+(numberChampionships/10);
	}

	/**
	 * Description this method generates a string with the main coach's info
	 *@return string with the main coach's info
	 */
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		String s = super.toString();
		s+="In charge of "+numberTeamsInCharge+" teams\n"+"Has won "+numberChampionships+" championships\n";
		return s;
	}
}
