package model;

public class Player extends Employee {
	private int jerseyNumber;
	private int goals;
	private double averageScore;
	private Position position;
	private double marketPrice;
	private double level;
	private Team team;
	/**
	 * Description this is the constructor of the Player class
	 * @param name player's name
	 * @param id player's id
	 * @param salary player's salary
	 * @param state player's state
	 * @param jerseyNumber player's jersey number
	 * @param goals player's goals
	 * @param averageScore player's average score
	 * @param position player's position
	 * @param type player's type
	 */
	public Player(String name, int id, double salary, State state, int jerseyNumber, int goals, double averageScore,
			Position position, EmployeeType type) {
		super(name, id, salary, state, type);
		this.jerseyNumber = jerseyNumber;
		this.goals = goals;
		this.averageScore = averageScore;
		this.position = position;
		this.team=null;
		calcLevel();
		calcMarketPrice();
	}
	/**
	 * Description this method gets the player's jersey number
	 * @return the player's jersey number
	 */
	public int getJerseyNumber() {
		return jerseyNumber;
	}
	/**
	 * Description this method sets the player's jersey number
	 * @param jerseyNumber the player's jersey number
	 */
	public void setJerseyNumber(int jerseyNumber) {
		this.jerseyNumber = jerseyNumber;
	}
	/**
	 * Description this method gets the player's goals
	 * @return the player's goals
	 */
	public int getGoals() {
		return goals;
	}
	/**
	 * Description this method sets the player's goals
	 * @param goals the player's goals
	 */
	public void setGoals(int goals) {
		this.goals = goals;
	}
	/**
	 * Description this method gets the player's average score
	 * @return the player's average score
	 */
	public double getAverageScore() {
		return averageScore;
	}
	/**
	 * Description this method sets the player's average score
	 * @param averageScore the player's average score
	 */
	public void setAverageScore(double averageScore) {
		this.averageScore = averageScore;
	}
	/**
	 * Description this method gets the player's position
	 * @return the player's position
	 */
	public Position getPosition() {
		return position;
	}
	/**
	 * Description this method sets the player's position
	 * @param position the player's position
	 */
	public void setPosition(Position position) {
		this.position = position;
	}
	/**
	 * Description this method gets the player's market price
	 * @return the player's market price
	 */
	public double getMarketPrice() {
		return marketPrice;
	}
	/**
	 * Description this method sets the player's market price
	 * @param marketPrice the player's market price
	 */
	public void setMarketPrice(double marketPrice) {
		this.marketPrice = marketPrice;
	}
	/**
	 * Description this method gets the player's level
	 * @return the player's level
	 */
	public double getLevel() {
		return level;
	}
	/**
	 * Description this method sets the player's level
	 * @param level the player's level
	 */
	public void setLevel(double level) {
		this.level = level;
	}
	/**
	 * Description this method gets the player's team
	 * @return the player's team
	 */
	public Team getTeam() {
		return team;
	}
	/**
	 * Description this method sets the player's team
	 * @param team the player's team
	 */
	public void setTeam(Team team) {
		this.team = team;
	}
	
	/**
	 * Description this method calculates the player's market price
	 */
	public void calcMarketPrice()
	{
		if(position.equals(Position.GOALKEEPER))
		{
			marketPrice = (salary*12)+(averageScore*150);
		}
		else if(position.equals(Position.DEFENSE))
		{
			marketPrice = (salary*13)+(averageScore*125)+(goals*100);
		}
		else if(position.equals(Position.MIDFIELDER))
		{
			marketPrice = (salary*14)+(averageScore*135)+(goals*125);
		}
		else
		{
			marketPrice = (salary*15)+(averageScore*145)+(goals*150);
		}
	}
	
	/**
	 * Description this method calculates the player's level
	 */
	public void calcLevel()
	{
		if(position.equals(Position.GOALKEEPER))
		{
			level = averageScore*0.9;
		}
		else if(position.equals(Position.DEFENSE))
		{
			level = (averageScore*0.9)+(goals/100);
		}
		else if(position.equals(Position.MIDFIELDER))
		{
			level = (averageScore*0.9)+(goals/90);
		}
		else
		{
			level = (averageScore*0.9)+(goals/80);
		}
	}
	
	/**
	 * Description this method generates a string with the player's info
	 *@return string with the player's info
	 */
	@Override
	public String toString() {
		String s = super.toString();
		s+= "Jersey number: "+jerseyNumber+" \n"; 
		s+= "Goals scored: "+goals+" \n"; 
		s+= "Average score: "+averageScore+" \n"; 
		s+= position+" \n"; 
		s+= "Market price: "+marketPrice+" \n"; 
		s+= "Level: "+level+" \n"; 
		if (team!=null) {
			s+= "Team: "+team.getName()+" \n"; 
		}
		else {
			s+= "No team yet \n"; 
		}
		return s;
		
	}
	
}
