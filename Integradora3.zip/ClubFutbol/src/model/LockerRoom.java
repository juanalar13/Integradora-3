package model;

public class LockerRoom {
	private int capacity;
	private Player[][] players;
	private Team team;
	/**
	 * Description this is the constructor of the LockerRoom class
	 * @param capacity the locker room's capacity
	 */
	public LockerRoom(int capacity) {
		this.capacity = capacity;
		this.players = new Player[7][capacity/7];
		this.team=null;
	}
	/**
	 * Description this method gets the locker room's capacity
	 * @return the locker room's capacity
	 */
	public int getCapacity() {
		return capacity;
	}
	/**
	 * Description this method sets the locker room's capacity
	 * @param capacity the locker room's capacity
	 */
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	/**
	 * Description this method gets the locker room's players
	 * @return the locker room's players
	 */
	public Player[][] getPlayers() {
		return players;
	}
	/**
	 * Description this method sets the locker room's capacity
	 * @param players the locker room's players
	 */
	public void setPlayers(Player[][] players) {
		this.players = players;
	}

	/**
	 * Description this method gets the locker room's team
	 * @return the locker room's team
	 */
	public Team getTeam() {
		return team;
	}
	/**
	 * Description this method sets the locker room's team
	 * @param team the locker room's team
	 */
	public void setTeam(Team team) {
		this.team = team;
	}
	/**
	 * Description this method determines if a player is from the locker room's team
	 * @param newPlayer the player to be added
	 * @return true if the team coincides, false if not
	 */
	public boolean isSameTeam(Player newPlayer)
	{

		for (int i = 0; i < players.length; i++) {
			for (int j = 0; j < players[0].length; j++) {
				if(players[i][j]!=null)
				{
					if(players[i][j].getTeam().equals(newPlayer.getTeam()) && newPlayer.getTeam().equals(team))
						return true;
					else
						return false;

				}
			}
		}
		if(newPlayer.getTeam().equals(team))
			return true;
		else
			return false;
	}



	/**
	 * Description this method adds a player to a locker room
	 * @param newPlayer the new player
	 */
	public void addPlayer(Player newPlayer)
	{
		if (isSameTeam(newPlayer)) {
			for (int i = 0; i < players.length; i++) {
				for (int j = 0; j < players[0].length; j++) {
					if(players[i-1][j]==null && players[i+1][j]==null && players[i][j-1]==null && players[i][j+1]==null && players[i][j]==null )
					{
						players[i][j]=newPlayer;
						break;
					}
				}
			}
		}
	}

	/**
	 * Description this method removes a player from a locker room
	 * @param id the player's id
	 */
	public void removePlayer(int id)
	{
		for (int i = 0; i < players.length; i++) {
			for (int j = 0; j < players[0].length; j++) {
				if(players[i][j]!=null)
				{
					if(players[i][j].getId()==id)
					{
						players[i]=null;
						break;
					}
				}
			}
		}
	}

	/**
	 * Description this method generates a string with the locker rooms info
	 *@return string with the locker rooms info
	 */
	@Override
	public String toString() {
		String s="";
		for (int i = 0; i < players.length; i++) {
			for (int j = 0; j < players[0].length; j++) {
				if (players[i][j]!=null) {
					s+="[x]";
				}
				else
				{
					s+="[ ]";
				}
			}
			s+="\n";
		}
		return s;
	}

}
