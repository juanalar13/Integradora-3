package model;

public class TechnicalAssistant extends Coach {
	private boolean proPlayer;
	private Expertise expertise;
	/**
	 * Description this is the constructor of the TechnicalAssistant class
	 * @param name coach's name
	 * @param id coach's id
	 * @param salary coach's salary
	 * @param state coach's state
	 * @param experience coach's experience
	 * @param proPlayer if the choach was a pro player
	 * @param expertise coach's expertise
	 * @param type coach's type
	 */
	public TechnicalAssistant(String name, int id, double salary, State state, int experience, boolean proPlayer,
			Expertise expertise, EmployeeType type) {
		super(name, id, salary, state, experience, type);
		this.proPlayer = proPlayer;
		this.expertise = expertise;
	}
	/**
	 * Description this method tells if the technical assistant was a professional player
	 * @return true if he or she was, otherwise false
	 */
	public boolean isProPlayer() {
		return proPlayer;
	}
	/**
	 * Description this method sets if the technical assistant was a professional player
	 * @param proPlayer true if he or she was, otherwise false
	 */
	public void setProPlayer(boolean proPlayer) {
		this.proPlayer = proPlayer;
	}
	/**
	 * Description this method gets the technical assistant's expertise
	 * @return the technical assistant's expertise
	 */
	public Expertise getExpertise() {
		return expertise;
	}
	/**
	 * Description this method sets the technical assistant's expertise
	 * @param expertise the technical assistant's expertise
	 */
	public void setExpertise(Expertise expertise) {
		this.expertise = expertise;
	}
	/**
	 * Description this method generates a string with the technical assistant's info
	 *@return string with the technical assistant's info
	 */
	@Override
	public String toString() {
		String s = super.toString();
		if (proPlayer) {
			s+="Was a pro player\n";
		}
		else
		{
			s+="Was not a pro player\n";
		}
		s+="Expertise: "+expertise+"\n";
		return s;
	}

}
