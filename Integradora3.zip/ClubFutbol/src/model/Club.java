package model;

import java.util.ArrayList;

public class Club {
	private String name;
	private int nit;
	private String establishedDate;
	private LockerRoom lockerRooms[];
	private Office offices[][];
	private ArrayList<MainCoach> mainCoaches;
	private ArrayList<TechnicalAssistant> technicalAssistants;
	private ArrayList<Player> players;
	private Team teams[];
	private ArrayList<Employee> employees;
	public static final int LOCKER_ROOMS = 2;
	public static final int OFFICES = 36;
	/**
	 * Description This is the constructor method of the Club class
	 * @param name the club's name
	 * @param nit the clubs nit
	 * @param establishedDate the date it was established
	 */
	public Club(String name, int nit, String establishedDate) {
		this.name = name;
		this.nit = nit;
		this.establishedDate = establishedDate;
		employees = new ArrayList<Employee>();
		mainCoaches = new ArrayList<MainCoach>();
		technicalAssistants = new ArrayList<TechnicalAssistant>();
		players = new ArrayList<Player>();
		createLockerRooms();
		createTeams();
	}
	/**
	 * Description this method gets the name of the club
	 * @return The name of the club
	 */
	public String getName() {
		return name;
	}
	/**
	 * Description this method sets the name of the club
	 * @param name the name of the club
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * Description this method gets the NIT of the club
	 * @return The NIT of the club
	 */
	public int getNit() {
		return nit;
	}
	/**
	 * Description this method sets the NIT of the club
	 * @param nit the NIT of the club
	 */
	public void setNit(int nit) {
		this.nit = nit;
	}
	/**
	 * Description this method gets the established date of the club
	 * @return The date the club was established in
	 */
	public String getEstablishedDate() {
		return establishedDate;
	}
	/**
	 * Description this method sets the established date of the club
	 * @param establishedDate the date the club was established in
	 */
	public void setEstablishedDate(String establishedDate) {
		this.establishedDate = establishedDate;
	}

	/**
	 * Description this method gets the locker rooms of the club
	 * @return The locker rooms of the club
	 */
	public LockerRoom[] getLockerRooms() {
		return lockerRooms;
	}
	/**
	 * Description this method sets the locker rooms of the club
	 * @param lockerRooms the locker rooms of the club
	 */
	public void setLockerRooms(LockerRoom[] lockerRooms) {
		this.lockerRooms = lockerRooms;
	}
	/**
	 * Description this method gets the offices of the club
	 * @return The offices of the club
	 */
	public Office[][] getOffices() {
		return offices;
	}
	/**
	 * Description this method sets the offices of the club
	 * @param offices The offices of the club
	 */
	public void setOffices(Office[][] offices) {
		this.offices = offices;
	}
	/**
	 * Description this method gets the teams of the club
	 * @return the teams of the club
	 */
	public Team[] getTeams() {
		return teams;
	}
	/**
	 * Description this method sets the teams of the club
	 * @param teams the teams of the club
	 */
	public void setTeams(Team[] teams) {
		this.teams = teams;
	}
	/**
	 * Description this method gets the employees of the club
	 * @return The employees of the club
	 */
	public ArrayList<Employee> getEmployees() {
		return employees;
	}
	/**
	 * Description this method sets the employees of the club
	 * @param employees The employees of the club
	 */
	public void setEmployees(ArrayList<Employee> employees) {
		this.employees = employees;
	}
	/**
	 * Description this method initializes the club's teams and assigns locker rooms
	 */
	public void createTeams()
	{
		teams = new Team[2];
		teams[0] = new Team("A");
		teams[0].setLockerRoom(lockerRooms[0]);
		lockerRooms[0].setTeam(teams[0]);
		teams[1] = new Team("B");
		teams[1].setLockerRoom(lockerRooms[1]);
		lockerRooms[1].setTeam(teams[1]);
	}

	/**
	 * Description This method creates the locker rooms
	 */
	public void createLockerRooms()
	{
		lockerRooms =  new LockerRoom[LOCKER_ROOMS];
		int capacity=42;
		for (int i = 0; i < lockerRooms.length; i++) {
			lockerRooms[i] = new LockerRoom(capacity);
			capacity+=7;
		}
	}

	/**
	 * Description This method creates the offices
	 */
	public void createOffices()
	{
		int ij = (int)Math.sqrt(OFFICES);
		int cont=1;
		offices = new Office[ij][ij];
		for (int i = 0; i < offices.length; i++) {
			for (int j = 0; j < offices[0].length; j++) {
				offices[i][j] = new Office(cont);
				cont++;
			}
		}

	}

	/**
	 * Description this method adds a coach to an office, if the coach is already in an office it doesnt. Social distancin rules are followed.
	 * @param id the coach's id
	 * @return true if the coach was placed, false if the coach wasn't
	 */
	public boolean addCoachToOffice(int id)
	{
		Coach coach = findCoachById(id);
		if (coach==null) {
			return false;
		}
		for (int i = 0; i < offices.length; i++) {
			for (int j = 0; j < offices[0].length; j++) {
				if(offices[i-1][j].isEmpty() && offices[i+1][j].isEmpty() && offices[i][j-1].isEmpty() && offices[i][j+1].isEmpty() && offices[i][j].isEmpty() )
				{
					if (offices[i][j].getCoach().getId()==id) {
						return false;
					}
					offices[i][j].setCoach(coach);
					return true;
				}
			}
		}

		return false;

	}

	/**
	 * Description finds a coach based on the id
	 * @param id the coach's id
	 * @return coach, the coach null if the coach wasn't found
	 */
	public Coach findCoachById(int id)
	{
		for (MainCoach mainCoach : mainCoaches) {
			if (mainCoach.getId()==id) {
				return mainCoach;
			}
		}

		for (TechnicalAssistant technicalAssistant : technicalAssistants) {
			if (technicalAssistant.getId()==id) {
				return technicalAssistant;
			}
		}

		return null;
	}

	/**
	 * Description adds a new employee to the club
	 * @param e employee to be added
	 * @param type the type of employee, player, main coach etc.
	 * @return true if the employee was added, false if it wasn't
	 */
	public boolean addEmployee(Employee e, int type)
	{
		for (Employee employee : employees) {
			if(employee.getId()==e.getId())
				return false;
		}
		switch (type) {
		case 1:
			players.add((Player)e);
			break;
		case 2:
			mainCoaches.add((MainCoach)e);
			break;
		case 3:
			technicalAssistants.add((TechnicalAssistant) e);
			break;

		}
		employees.add(e);
		return true;
	}

	/**
	 * Description this method removes an employee from the club
	 * @param id the employee's id
	 * @return true if it was removed false if the employee with the id didn't exist or couldn't be removed
	 */
	public boolean removeEmployee(int id)
	{
		Employee fired = null;
		for (Employee employee : employees) {
			if(employee.getId()==id)
			{
				fired= employee;
				employees.remove(employee);

			}
		}

		if (fired==null) {
			return false;
		}
		switch (fired.getType()) {
		case PLAYER:
			for (Player player : players) {
				if (player.getId()==id) {
					if (player.getTeam()!=null) {
						Team team = getTeamByName(player.getTeam().getName());
						team.removePlayer(id);
					}
					for (LockerRoom lockerRoom : lockerRooms) {
						lockerRoom.removePlayer(id);
					}
					players.remove(player);
					return true;
				}
			}
			break ;
		case MAIN_COACH:
			for (MainCoach mainCoach : mainCoaches) {
				if (mainCoach.getId()==id) {
					for (Team team : teams) {
						if (team.getMainCoach()!=null) {
							if (team.getMainCoach().getId()==id) {
								team.setMainCoach(null);
							}
						}
					}
					for (int i = 0; i < offices.length; i++) {
						for (int j = 0; j < offices[0].length; j++) {
							Coach c= offices[i][j].getCoach();
							if (c!=null) {
								if (c.getId()==id) {
									offices[i][j].setCoach(null);
								}
							}
						}
					}
					mainCoaches.remove(mainCoach);
					return true;
				}
			}
			break;
		case TECHNICAL_ASSISTANT:
			for (TechnicalAssistant technicalAssistant : technicalAssistants) {
				if (technicalAssistant.getId()==id) {
					for (Team team : teams) {
						TechnicalAssistant[] tas = team.getTechnicalAssistants();
						for (int i = 0; i < tas.length; i++) {
							if (tas[i]!=null) {
								if (tas[i].getId()==id) {
									tas[i]=null;
								}
							}
						}
						team.setTechnicalAssistants(tas);
					}
					for (int i = 0; i < offices.length; i++) {
						for (int j = 0; j < offices[0].length; j++) {
							Coach c= offices[i][j].getCoach();
							if (c!=null) {
								if (c.getId()==id) {
									offices[i][j].setCoach(null);
								}
							}
						}
					}
					technicalAssistants.remove(technicalAssistant);
					return true;
				}
			}
			break;

		default:

		}
		return false;


	}

	/**
	 * Description this method returns a team based on the name
	 * @param name the team's name
	 * @return team if it was found null if it didn't exist
	 */
	public Team getTeamByName(String name) {
		for (Team team : teams) {
			if (name.equals(team.getName())) {
				return team;
			}
		}
		return null;
	}

	/**
	 * Description this method adds an employee to a team
	 * @param id the employee's id
	 * @param name the team's name
	 * @return true if the employee was added, false if it wasn't
	 */
	public boolean addEmployeeToTeam(int id, String name)
	{
		Team t = getTeamByName(name);
		Employee employee = findEmployeeById(id);
		if(t==null && employee==null)
			return false;
		switch (employee.getType()) {
		case TECHNICAL_ASSISTANT:
			return t.addTA((TechnicalAssistant) employee);
		case COACH:

			if(t.getMainCoach()==null)
			{
				t.setMainCoach((MainCoach)employee);
				return true;
			}
			else
			{
				return false;
			}
		case PLAYER:
			return t.addPlayer((Player) employee);
		default:
			return false;
		}


	}

	/**
	 * Description adds a formation to a team
	 * @param formation the formation to be added
	 * @param name the teams name
	 * @return true if the formation was added, false if the team couldn't be found
	 */
	public boolean addFormationToTeam(Formation formation, String name)
	{
		Team t = getTeamByName(name);
		if(t==null)
			return false;
		t.addFormation(formation);
		return true;
	}

	/**
	 * Description finds an employee based on its id 
	 * @param id emplyee's id
	 * @return emplyee, null if no employee has that id
	 */
	public Employee findEmployeeById(int id)
	{
		for (Employee employee : employees) {
			if (employee.getId()==id) {
				return employee;
			}
		}
		return null;
	}

	/**
	 * Description this method adds a player to a locker room
	 * @param id the player's id
	 * @return true if it was added, false if it couldn't be added
	 */
	public boolean addPlayerToLockerRoom(int id)
	{
		Player player = findPlayerById(id);
		if (player==null) {
			return false;
		}
		for (LockerRoom lockerRoom : lockerRooms) {
			if (lockerRoom.isSameTeam(player)) {
				lockerRoom.addPlayer(player);
				return true;
			}
		}
		return false;
	}

	/**
	 * Description finds a player based on their id
	 * @param id the player's id
	 * @return player, null if no player has the id
	 */
	public Player findPlayerById(int id)
	{
		for (Player player : players) {
			if (player.getId()==id) {
				return player;
			}
		}

		return null;
	}

	/**
	 * Description this method generates a string with the layout of the offices and shows which ones are occupied
	 * @return string that depicts the state of the offices
	 */
	public String stateOfOffices()
	{
		String s="";
		for (int i = 0; i < offices.length; i++) {
			for (int j = 0; j < offices[0].length; j++) {
				s+=offices.toString();
			}
			s+="\n";
		}
		return s;
	}

	/**
	 * Description this method makes a string with the club's information
	 * @return string with the club's information
	 */
	public String toString()
	{
		String s= "Club: "+name+" "+"\nEst. "+establishedDate+"\nNIT: "+nit;
		s+="\nEmployees: "+employees.size();
		s+="\nTeams: "+teams.length;
		return s;
	}

	/**
	 * Description this method creates a string with the information from all of the club's employees
	 * @return the information of all of the club's employees
	 */
	public String getInfoAllEmployees()
	{
		String s="";
		for (Employee employee : employees) {
			s+=employee.toString()+"\n";
		}
		return s;
	}

	/**
	 * This method finds an employee by its id and returns its information
	 * @param id the employee's id
	 * @return string with the employee's info
	 */
	public String getInfoEmployeeId(int id)
	{
		return findEmployeeById(id).toString();
	}

	/**
	 * Description this method creates a string with the information from all of the club's teams
	 * @return the information of all of the club's teams
	 */
	public String getInfoAllTeams()
	{
		String s="";
		for (Team team : teams) {
			s+=team.toString()+"\n";
		}
		return s;
	}
	/**
	 * This method finds a team by its name and returns its information
	 * @param name team's name
	 * @return string with the team's info
	 */
	public String getInfoTeam(String name)
	{
		return getTeamByName(name).toString();
	}

	/**
	 * Description this method creates a string with the information from all of the club's locker rooms
	 * @return the information of all of the club's locker rooms
	 */
	public String getInfoLockerRooms()
	{
		String s="[x] means there's a player, [ ] means its empty\n";
		for (LockerRoom lockerRoom : lockerRooms) {
			s+=lockerRoom.toString()+"\n\n";
		}
		return s;
	}

	/**
	 * Description this method updates a team's information
	 * @param name the teams old name
	 * @param newName teams new name
	 */
	public void updateTeam(String name, String newName )
	{
		Team t= getTeamByName(name);
		t.setName(newName);
	}
	
	/**
	 * Description this method updates the arrays that represent different types of employees in the club
	 */
	public void updateArrays()
	{
		mainCoaches = new ArrayList<MainCoach>();
		technicalAssistants = new ArrayList<TechnicalAssistant>();
		players = new ArrayList<Player>();
		for (Employee employee : employees) {
			switch (employee.type) {
			case MAIN_COACH:
				mainCoaches.add((MainCoach)employee);
				break ;
			case PLAYER:
				players.add((Player)employee);
				break ;
			case TECHNICAL_ASSISTANT:
				technicalAssistants.add((TechnicalAssistant)employee);
				break ;
			default:

			}
		}
	}


	/**
	 * Description this method updates an employee's information
	 * @param id employee's id
	 * @param newName the employee's new name
	 * @param newSalary the employee's new salary
	 * @param newState the employee's new state (active, inactive)
	 */
	public void updateEmployee(int id, String newName, double newSalary, State newState )
	{
		Employee employee=findEmployeeById(id);
		employee.setName(name);
		employee.setSalary(newSalary);
		employee.setState(newState);
		updateArrays();
	}

}
