package model;

public enum State {
ACTIVE, INACTIVE
}
