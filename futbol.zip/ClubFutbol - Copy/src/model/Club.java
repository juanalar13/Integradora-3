package model;

public class Club {
	private String name;
	private int nit;
	private String establishedDate;
	private LockerRoom lockerRooms[];
	private Office offices[];
	public Club(String name, int nit, String establishedDate) {
		this.name = name;
		this.nit = nit;
		this.establishedDate = establishedDate;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getNit() {
		return nit;
	}
	public void setNit(int nit) {
		this.nit = nit;
	}
	public String getEstablishedDate() {
		return establishedDate;
	}
	public void setEstablishedDate(String establishedDate) {
		this.establishedDate = establishedDate;
	}

}
