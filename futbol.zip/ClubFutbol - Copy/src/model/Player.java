package model;

public class Player extends Employee {
	private int jerseyNumber;
	private int goals;
	private double averageScore;
	private String position;
	private double marketPrice;
	private double level;
	public Player(String name, int id, double salary, String state, int jerseyNumber, int goals, double averageScore,
			String position, double marketPrice, double level) {
		super(name, id, salary, state);
		this.jerseyNumber = jerseyNumber;
		this.goals = goals;
		this.averageScore = averageScore;
		this.position = position;
		this.marketPrice = marketPrice;
		this.level = level;
	}
	public int getJerseyNumber() {
		return jerseyNumber;
	}
	public void setJerseyNumber(int jerseyNumber) {
		this.jerseyNumber = jerseyNumber;
	}
	public int getGoals() {
		return goals;
	}
	public void setGoals(int goals) {
		this.goals = goals;
	}
	public double getAverageScore() {
		return averageScore;
	}
	public void setAverageScore(double averageScore) {
		this.averageScore = averageScore;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	public double getMarketPrice() {
		return marketPrice;
	}
	public void setMarketPrice(double marketPrice) {
		this.marketPrice = marketPrice;
	}
	public double getLevel() {
		return level;
	}
	public void setLevel(double level) {
		this.level = level;
	}
}
