package model;

public class Formation {
	private int[][] matrix;
	/*
	 * Description This is the constructor method of the Formation class
	 * @param matrix the matrix that represents the formation in 1 and 0s
	 */
	public Formation(int[][] matrix) {
		this.matrix = matrix;
	}
	/*
	 * Description This method returns the matrix that represents the formation in 1 and 0s
	 * @return the matrix that represents the formation in 1 and 0s
	 */
	public int[][] getMatrix() {
		return matrix;
	}

	/*
	 * Description This method sets the matrix that represents the formation in 1 and 0s
	 * @param the matrix that represents the formation
	 */
	public void setMatrix(int[][] matrix) {
		this.matrix = matrix;
	}
	
	/*
	 * Description This method returns a string describing the formation (eg. 4-4-2)
	 * @return the string value equivalent to the formation
	 */
	public String toString()
	{
		String ans="";
		for(int i =matrix[0].length-1;i>=0; i--)
		{ int cont=0;
			for (int j=0;j<matrix.length;j++ )
			{
				if(matrix[i][j]==1)
				{
					cont++;
				}
				
			}
			if(ans.isBlank())
			{
				ans+=cont;
			}
			else
			{
				ans+="-"+cont;
			}
		}
		return ans;
	}

}
