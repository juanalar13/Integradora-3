package model;

public class Team {
private String name;
private Player[] mainRoster;
}
