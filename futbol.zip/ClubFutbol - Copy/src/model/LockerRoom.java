package model;

public class LockerRoom {

}
