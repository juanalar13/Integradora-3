package model;

public class MainCoach extends Coach{
	private int numberTeamsInCharge;
	private int numberChampionships;
	private double marketPrice;
	private double level;
	public MainCoach(String name, int id, double salary, String state, int experience, int numberTeamsInCharge,
			int numberChampionships, double marketPrice, double level) {
		super(name, id, salary, state, experience);
		this.numberTeamsInCharge = numberTeamsInCharge;
		this.numberChampionships = numberChampionships;
		this.marketPrice = marketPrice;
		this.level = level;
	}
	public int getNumberTeamsInCharge() {
		return numberTeamsInCharge;
	}
	public void setNumberTeamsInCharge(int numberTeamsInCharge) {
		this.numberTeamsInCharge = numberTeamsInCharge;
	}
	public int getNumberChampionships() {
		return numberChampionships;
	}
	public void setNumberChampionships(int numberChampionships) {
		this.numberChampionships = numberChampionships;
	}
	public double getMarketPrice() {
		return marketPrice;
	}
	public void setMarketPrice(double marketPrice) {
		this.marketPrice = marketPrice;
	}
	public double getLevel() {
		return level;
	}
	public void setLevel(double level) {
		this.level = level;
	}


}
