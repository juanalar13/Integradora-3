package model;

public class Employee {
	private String name;
	private int id;
	private double salary;
	private String state;
	public Employee(String name, int id, double salary, String state) {
		
		this.name = name;
		this.id = id;
		this.salary = salary;
		this.state = state;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}

}
