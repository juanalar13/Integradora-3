package model;

public class TechnicalAssistant extends Coach {
	private boolean proPlayer;
	private String expertise;
	public TechnicalAssistant(String name, int id, double salary, String state, int experience, boolean proPlayer,
			String expertise) {
		super(name, id, salary, state, experience);
		this.proPlayer = proPlayer;
		this.expertise = expertise;
	}
	public boolean isProPlayer() {
		return proPlayer;
	}
	public void setProPlayer(boolean proPlayer) {
		this.proPlayer = proPlayer;
	}
	public String getExpertise() {
		return expertise;
	}
	public void setExpertise(String expertise) {
		this.expertise = expertise;
	}

}
