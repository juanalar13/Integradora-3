package model;

public class Office {
	private Coach coach;
	/*
	 * Description This is the constructor of the Office class
	 * 
	 */
	public Office() {
		coach=null;
	}
	/*
	 * Description This method gets the coach that is in the office
	 * @return the coach
	 */
	public Coach getCoach() {
		return coach;
	}
	/*
	 * Description This method sets the coach
	 * @param the coach that is assigned to the office
	 */
	public void setCoach(Coach coach) {
		this.coach = coach;
	}
	/*
	 * Description This method tells whether the office is empty or not
	 * @return if the office is empty or not
	 */
	public boolean isEmpty()
	{
		if(coach==null)
			return true;
		return false;
	}
}
