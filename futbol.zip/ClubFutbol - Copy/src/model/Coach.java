package model;

public class Coach extends Employee{
	private int experienceYears;
	public Coach(String name, int id, double salary, String state, int experience) {
		super(name, id, salary, state);
		this.experienceYears=experience;
		
	}
	public int getExperienceYears() {
		return experienceYears;
	}
	public void setExperienceYears(int experienceYears) {
		this.experienceYears = experienceYears;
	}

}
